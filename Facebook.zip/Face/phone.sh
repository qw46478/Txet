#!/data/data/com.termux/files/usr/bin/bash

echo "
    [ 1 ] 094       [ 6 ] 011
              
    [ 2 ] 092       [ 7 ] 010
     
    [ 3 ] 091
    
    [ 4 ] 095 

    [ 5 ] 012
"
read -p " number :- " num
if [ $num -eq 1 ]; then 
for i in {55555..99999}; do
     echo 09429$i
     echo 09419$i
     echo 09484$i
done
fi
if [ $num -eq 2 ]; then 
for i in {55555..99999}; do
     echo 09283$i
     echo 09205$i
     echo 09282$i
done
fi
if [ $num -eq 3 ]; then 
for i in {55555..99999}; do
     echo 09139$i
     echo 09104$i
     echo 09102$i
done
fi
if [ $num -eq 4 ]; then
for i in {55555..99999}; do
     echo 09594$i
     echo 09520$i
     echo 095394$i
done
fi
if [ $num -eq 5 ]; then
for i in {55555..99999}; do
     echo 012549$i
     echo 012053$i
     echo 012043$i
done
fi
if [ $num -eq 6 ]; then
for i in {55555..99999}; do
     echo 011546$i
     echo 011052$i
     echo 011053$i
done
fi
if [ $num -eq 7 ]; then
for i in {55555..99999}; do
     echo 010544$i
     echo 010051$i
     echo 010045$i
done
fi





